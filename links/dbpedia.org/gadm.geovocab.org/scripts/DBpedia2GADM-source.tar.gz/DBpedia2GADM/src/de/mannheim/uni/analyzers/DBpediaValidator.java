package de.mannheim.uni.analyzers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import nsidc.spheres.Point;
import nsidc.spheres.SphericalPolygon;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class DBpediaValidator {

	public static double PI = 3.14159265;
	public static double TWOPI = 2 * PI;

	public static void main(String[] args) {
		checkCorrectDBCoordinates("GADMdata/Australia/GADMAustralia");

	}

	/**
	 * Checks how many of the geo coordinates are correct, or exist at all.
	 * 
	 * @param filePath
	 */
	public static void checkCorrectDBCoordinates(String filePath) {

		CSVReader reader;
		CSVWriter writer = null;
		try {
			reader = new CSVReader(new FileReader(filePath + ".csv"));

			writer = new CSVWriter(new FileWriter(filePath + "Checked.csv"));
			String[] nextLine = reader.readNext();
			while ((nextLine = reader.readNext()) != null) {
				try {
					// ID string
					String popUri = nextLine[0].trim();
					// the entity label
					String label = nextLine[1].trim();
					// the DBpedia entity URI
					String dbUri = nextLine[2].trim();
					// the corresponding GADM geometry
					String gadmUri = nextLine[3].trim();

					String[] entries = new String[5];
					entries[0] = popUri;
					entries[1] = label;
					entries[2] = dbUri;
					entries[3] = gadmUri;
					entries[4] = checkDbCoordinates(dbUri, gadmUri);
					writer.writeNext(entries);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();// TODO: handle exception

		}
		try {
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();// TODO: handle exception
		}
	}

	/**
	 * Checks whether the DBpedua concept's geo coordinates are inside the
	 * corresponding GADM geometry.
	 * 
	 * @param dbUri
	 * @param gadmUri
	 * @return
	 */
	private static String checkDbCoordinates(String dbUri, String gadmUri) {
		List<Float> coordDB = ConceptExtractor.getDBcoordinates(dbUri, false,
				"http://dbpedia.org/sparql");
		if (coordDB == null || coordDB.size() == 0)
			return "missing";
		Point dbPoint = new Point(coordDB.get(0), coordDB.get(1));

		List<SphericalPolygon> geometries = readShapesFromGADM(gadmUri
				+ "_geometry.geojson");
		boolean itContains = false;
		for (SphericalPolygon pol : geometries)
			if (pol.contains(dbPoint))
				itContains = true;
		return Boolean.toString(itContains);
	}

	/**
	 * Reads and parses the GADM geometries
	 * 
	 * @param uri
	 * @return
	 */
	public static List<SphericalPolygon> readShapesFromGADM(String uri) {
		List<SphericalPolygon> polygons = new ArrayList<SphericalPolygon>();
		try {
			// read the geojson file
			String json = readFileFromURL(uri).toString();
			System.out.println(json);
			JSONObject jsonObject = new JSONObject(json);
			JSONArray coordinates = jsonObject.getJSONArray("coordinates");
			for (int j = 0; j < coordinates.length(); j++) {
				JSONArray coordinatesInside = coordinates.getJSONArray(j)
						.getJSONArray(0);
				ArrayList<Double> long_array = new ArrayList<Double>();
				ArrayList<Double> lat_array = new ArrayList<Double>();
				for (int i = 0; i < coordinatesInside.length(); i++) {
					JSONArray coord = coordinatesInside.getJSONArray(i);
					long_array.add(Double.parseDouble(coord.get(0).toString()));
					lat_array.add(Double.parseDouble(coord.get(1).toString()));
				}
				double[] latField = new double[lat_array.size()];
				double[] longField = new double[long_array.size()];
				for (int i = 0; i < long_array.size(); i++) {
					latField[i] = lat_array.get(i);
					longField[i] = long_array.get(i);
				}
				SphericalPolygon pol = new SphericalPolygon(latField, longField);
				polygons.add(pol);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return polygons;
	}

	public static StringBuffer readFileFromURL(String url) throws Exception {
		URL oracle = new URL(url);
		BufferedReader in = new BufferedReader(new InputStreamReader(
				oracle.openStream()));

		String inputLine;
		StringBuffer buffer = new StringBuffer();
		while ((inputLine = in.readLine()) != null)
			buffer.append(inputLine);
		in.close();

		return buffer;
	}
}
