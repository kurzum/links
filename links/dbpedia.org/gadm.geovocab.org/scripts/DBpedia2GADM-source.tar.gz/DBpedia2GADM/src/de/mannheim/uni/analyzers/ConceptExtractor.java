package de.mannheim.uni.analyzers;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import com.hp.hpl.jena.query.ParameterizedSparqlString;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.util.FileManager;

public class ConceptExtractor {
	public enum DBSelection {
		FIRST, EDIT_DISTANCE
	}

	public static String getCoordinatesQUery = "PREFIX geo: <http://www.w3.org/2003/01/geo/wgs84_pos#>"
			+ "PREFIX dbo: <http://dbpedia.org/ontology/>"
			+ "SELECT * WHERE {"
			+ "  ?s a dbo:Place ."
			+ "  ?s geo:lat ?lat ."
			+ "  ?s geo:long ?long ." + "}";

	public static String getAveerageCoordinatesQUery = "select (avg(?la) as ?lat) (avg(?lo) as ?long)"
			+ "where {?x ?y ?s."
			+ " ?x <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?la ."
			+ " ?x <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?lo}";

	public static final String GADM_BASE_URI = "http://gadm.geovocab.org/services/search";

	/**
	 * retrieves GADM concept for given label and db pedia uri
	 * 
	 * @param dbUri
	 *            dbpedia uri
	 * @param label
	 * @return
	 */
	public static String getGADMCConcept(String dbUri, String label,
			String endpoint) {
		// remove special characters
		// TODO: add ngram search if possible
		label = normalizeLabel(label);

		String result = null;
		boolean isWithAverage = false;
		String serviceUrl = GADM_BASE_URI + "?&rdfs_label="
				+ URLEncoder.encode(label);
		// get coordinates from dbpedia
		List<Float> coord = getDBcoordinates(dbUri, false, endpoint);
		if (coord != null)
			serviceUrl = GADM_BASE_URI + "?geo_lat=" + coord.get(0)
					+ "&geo_long=" + coord.get(1) + "&rdfs_label="
					+ URLEncoder.encode(label);
		else { // if coordinates are null, get average coordinates
			coord = getDBcoordinates(dbUri, true, endpoint);
			if (coord != null) {
				serviceUrl = GADM_BASE_URI + "?geo_lat=" + coord.get(0)
						+ "&geo_long=" + coord.get(1) + "&rdfs_label="
						+ URLEncoder.encode(label);
				isWithAverage = true;
			}
		}

		try {
			ResultSet results = exploreGADMgraph(serviceUrl);
			// ResultSetFormatter.out(System.out, results);
			if (results != null && results.hasNext()) {
				result = results.next().get("o").toString();
			} else if (!isWithAverage) { // if the results are null, try with
											// average coordinates
				coord = getDBcoordinates(dbUri, true, endpoint);

				if (coord != null) {
					serviceUrl = GADM_BASE_URI + "?geo_lat=" + coord.get(0)
							+ "&geo_long=" + coord.get(1) + "&rdfs_label="
							+ URLEncoder.encode(label);
					isWithAverage = true;

					results = exploreGADMgraph(serviceUrl);
					// ResultSetFormatter.out(System.out, results);
					if (results != null && results.hasNext()) {
						result = results.next().get("o").toString();
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	private static String normalizeLabel(String label) {
		if (label.contains("'")) {
			label = label.substring(0, label.indexOf("'"));
		}
		if (label.contains("(")) {
			label = label.substring(0, label.indexOf("(") - 1);
		}
		if (label.contains(",")) {
			label = label.substring(0, label.indexOf(","));
		}
		if (label.contains("_")) {
			label = label.substring(0, label.indexOf(","));
		}
		label = label.replaceAll("[R|r]egion", "");

		label = label.replaceAll("[D|d]istrict", "");

		label = label.replaceAll("[P|p]rovince of", "");

		label = label.replaceAll("[P|p]rovince", "");

		label = label.replaceAll("[C|c]ounty", "");

		label = label.replaceAll("[D|d]epartment", "");

		label = label.replaceAll("[A|a]rea", "");

		label = label.replaceAll("[S|s]tate of", "");
		label = label.replaceAll("[S|s]tate", "");
		label = label.replaceAll("[M|m]unicipality", "");

		label = label.replaceAll("[B|b]orough", "");

		label = label.replaceAll("[B|b]orough", "");
		label = label.replaceAll("[T|t]ownship", "");
		label = label.replaceAll("[U|u]pazila", "");
		label = label.trim();
		return label;
	}

	/**
	 * parse GADM results
	 * 
	 * @param uri
	 * @return
	 */
	public static ResultSet exploreGADMgraph(String uri) {
		Model model = FileManager.get().loadModel(uri);
		String queryString = "prefix rdfs:  <http://www.w3.org/2000/01/rdf-schema#>"
				+ "SELECT ?o WHERE {?s rdfs:seeAlso ?o}";

		Query query = QueryFactory.create(queryString);

		// Execute the query and obtain results
		QueryExecution qe = QueryExecutionFactory.create(query, model);
		ResultSet results = qe.execSelect();
		return results;
	}

	/**
	 * get coordinates from dbpedia
	 * 
	 * @param uri
	 * @return
	 */
	public static List<Float> getDBcoordinates(String uri, boolean isAverage,
			String endpoint) {
		List<Float> coord = new ArrayList<Float>();
		try {
			final String dbpedia = endpoint;
			ParameterizedSparqlString queryString = new ParameterizedSparqlString(
					getCoordinatesQUery);
			if (isAverage) {
				queryString = new ParameterizedSparqlString(
						getAveerageCoordinatesQUery);
			}
			queryString.setIri("?s", uri);
			QueryExecution exec = QueryExecutionFactory.sparqlService(dbpedia,
					queryString.toString());
			ResultSet results = null;
			try {
				results = exec.execSelect();
			} catch (Exception e) {
				// repeat until DBpedia is not available
				return getDBcoordinates(uri, isAverage, endpoint);
			}
			if (results.hasNext()) {
				QuerySolution result = results.next();
				coord.add(result.get("lat").asLiteral().getFloat());
				coord.add(result.get("long").asLiteral().getFloat());
			} else {
				coord = null;
			}
		} catch (Exception e) {
			// e.printStackTrace();
			coord = null;// TODO: handle exception
		}
		return coord;
	}
}
