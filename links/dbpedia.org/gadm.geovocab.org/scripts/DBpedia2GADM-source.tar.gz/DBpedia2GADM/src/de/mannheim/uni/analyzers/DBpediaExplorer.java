package de.mannheim.uni.analyzers;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import com.hp.hpl.jena.query.ParameterizedSparqlString;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

public class DBpediaExplorer {

	public static final String SAME_AS = "<http://www.w3.org/2002/07/owl#sameAs>";

	public static final String GET_POPULATED_PLACES = "select distinct ?Concept  (GROUP_CONCAT(?labelDefault;separator = ',,,') as ?labels)  where {"
			+ "?Concept a <http://dbpedia.org/ontology/PopulatedPlace> . ?Concept <http://www.w3.org/2000/01/rdf-schema#label> ?labelDefault"
			+ "} GROUP BY ?Concept LIMIT 100";

	public static final String GET_POPULATED_PLACES_SIMPLE = "select distinct ?Concept  ?label  where {"
			+ "?Concept a <http://dbpedia.org/ontology/PopulatedPlace> . ?Concept <http://www.w3.org/2000/01/rdf-schema#label> ?label"
			+ "} OFFSET OFFNM";

	public static final String GET_POPULATED_PLACES_NO_CITIES = "select distinct ?Concept ?label  where {"
			+ "?Concept a <http://dbpedia.org/ontology/PopulatedPlace> . "
			+ "?Concept <http://www.w3.org/2000/01/rdf-schema#label> ?label . "
			+ "?Concept a ?t . "
			+ "FILTER NOT EXISTS { ?x <http://dbpedia.org/ontology/city> ?Concept } . "
			+ "FILTER NOT EXISTS { ?Concept a <http://dbpedia.org/ontology/City> } . "
			+ "FILTER NOT EXISTS { ?Concept a <http://dbpedia.org/ontology/Town>}. "
			+ "FILTER NOT EXISTS {?Concept a <http://dbpedia.org/ontology/Village>} "
			+ "} ";

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String endpoint = "http://wifo5-32.informatik.uni-mannheim.de:8890/sparql";// "http://dbpedia.org/sparql";
		if (args != null && args.length > 0 && args[0] != null)
			endpoint = args[0];
		generateGADMlinks(endpoint);
	}

	/**
	 * Generates the links for each DBpedia concept to GADM, and writes them
	 * into .nt file. The triples are not sorted => use sort -u on the final .nt
	 * file, after running this method.
	 * 
	 * @param dbPediaEndpoint
	 */
	public static void generateGADMlinks(String dbPediaEndpoint) {
		Logger logger = getLogger();
		logger.info("The endpoint to be used: " + dbPediaEndpoint);

		boolean stop = false;

		int current = 0;
		int successful = 0;

		int offset = 0;

		long start = 0;
		CSVWriter writer = null;
		try {
			writer = new CSVWriter(new FileWriter("gadm-linksRaw" + ".nt"),
					' ', CSVWriter.NO_QUOTE_CHARACTER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			while (!stop) {

				logger.info("Getting instances: " + offset + " - "
						+ (offset + 10000));
				final String dbpedia = dbPediaEndpoint;
				ParameterizedSparqlString queryString = new ParameterizedSparqlString(
						GET_POPULATED_PLACES_NO_CITIES.replace("OFFNM",
								Integer.toString(offset)));
				offset += 10000;
				start = System.currentTimeMillis();
				QueryExecution exec = QueryExecutionFactory.sparqlService(
						dbpedia, queryString.toString());
				ResultSet results = null;

				results = exec.execSelect();

				if (!results.hasNext()) {
					stop = true;
				}
				while (results.hasNext()) {
					try {
						current++;
						QuerySolution result = results.next();

						String dbURI = result.get("Concept").toString();

						String label = result.getLiteral("label").getString();

						logger.info("Current " + current + ": " + dbURI + ":"
								+ label);

						successful += mapDB2GADM(dbURI, label, writer,
								dbPediaEndpoint);

						logger.info("Mappings for: " + successful + "/"
								+ current);
					} catch (Exception e) {

						e.printStackTrace();
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();

		}

		try {
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(System.currentTimeMillis() - start);
	}

	/**
	 * Writes the triple in the .nt file
	 * 
	 * @param dbURI
	 * @param label
	 * @param writer
	 * @param endpoint
	 * @return
	 */
	private static int mapDB2GADM(String dbURI, String label, CSVWriter writer,
			String endpoint) {
		String[] entries = new String[4];

		String gadmConcept = ConceptExtractor.getGADMCConcept(dbURI, label,
				endpoint);
		if (gadmConcept != null && !gadmConcept.equals("null")) {
			entries[0] = "<" + dbURI + ">";
			entries[1] = SAME_AS;
			entries[2] = "<" + gadmConcept + ">";
			entries[3] = ".";
			writer.writeNext(entries);
			return 1;
		}
		return 0;
	}

	/**
	 * Returns new logger
	 * 
	 * @return
	 */
	private static Logger getLogger() {
		Logger logger = Logger.getLogger("logger");
		FileHandler fh;

		try {

			// This block configure the logger with handler and formatter
			fh = new FileHandler("logger.log");
			logger.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);

		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return logger;
	}

	/**
	 * Counts the bijectivity of the links
	 */
	public static void countBijectivity(String filePath) {
		Map<String, Integer> dbConcepts = new HashMap<String, Integer>();
		Map<String, Integer> gadmConcepts = new HashMap<String, Integer>();
		try {
			CSVReader reader = new CSVReader(new FileReader(filePath), ' ',
					CSVWriter.NO_QUOTE_CHARACTER);

			String[] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				String DBuri = nextLine[0].trim();
				String gadmUri = nextLine[2].trim();
				int dbNm = 0;
				if (dbConcepts.containsKey(DBuri)) {
					dbNm += dbConcepts.get(DBuri);
				}
				dbConcepts.put(DBuri, dbNm);

				int gadmNm = 0;
				if (gadmConcepts.containsKey(gadmUri)) {
					gadmNm += gadmConcepts.get(gadmUri);
				}
				gadmConcepts.put(gadmUri, gadmNm);
			}

		} catch (Exception e) {
			e.printStackTrace();// TODO: handle exception

		}
		System.out.println("DB uniques: " + dbConcepts.size()
				+ " \n GADM  uniques:" + gadmConcepts.size());
	}
}
